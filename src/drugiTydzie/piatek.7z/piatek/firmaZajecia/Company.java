package drugiTydzie.piatek.firmaZajecia;

/**
 * Created by RENT on 2017-07-14.
 */
public class Company {

    String[] arr = new String[10];
    Employee[] employee = new Employee[10];
}
